#include <iostream>
#include <string>

using namespace std;

string decimalToRoman(int number) {
    string result = "";
    int values[] = {100, 90, 50, 40, 10, 9, 5, 4, 1};
    string symbols[] = {"C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};

    for (int i = 0; i < 9; i++) {
        while (number >= values[i]) {
            result += symbols[i];
            number -= values[i];
        }

    }

    return result;

}

    void calculator(int number,int numberTwo)
    {
        int result;
        char op;
        cout << "Enter operator +,-,*,/  : ";
        cin >> op;
    if(op == '+') result = number + numberTwo;
        if(op == '-') result = number - numberTwo;
        if(op == '*') result = number * numberTwo;
        if(op == '/') result = number / numberTwo;
        cout << "result: " << decimalToRoman(result) << endl;
        cout << "result: " << result <<"\n";}




int main() {
    int number;
    int numberTwo;
    cout << "Enter a decimal number: ";
    cin >> number;
    cout << "Roman numeral equivalent: " << decimalToRoman(number) << endl;
    cout << "Enter a decimal number 2: ";
    cin >> numberTwo;
    cout << "Roman numeral equivalent: " << decimalToRoman(numberTwo) << endl;
    calculator(number, numberTwo);

        return 0;
}